\set ON_ERROR_STOP off
\pset pager off

\ir ../../../../../../scripts/commercial-hardening/red-contracts/14_pr11_blocks_resource_index_retirement.sql

select jsonb_build_object(
  'kind', 'blocks_resource_index_contract_current',
  'outcome', case
    when :'LAST_ERROR_MESSAGE' like 'RED COMM-PERF-005:%' then 'RED'
    else 'UNEXPECTED'
  end,
  'sqlstate', :'LAST_ERROR_SQLSTATE',
  'message', :'LAST_ERROR_MESSAGE'
) as current_contract_result;
